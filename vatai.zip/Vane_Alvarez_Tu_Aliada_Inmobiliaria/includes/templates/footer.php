
    <footer class="footer seccion">
      <div class="contenedor-footer">
        <nav class="navegacion">
          <a href="/">Inicio</a>
          <a href="/nosotros.php">Sobre mí</a>
          <a href="/anuncios.php">Anuncios</a>
          <a href="/blog.php">Blog</a>
          <a href="/contacto.php">Contacto</a>
        </nav>
      </div>


      <p class="copyright">Todos los derechos reservados <?php echo date('Y'); ?> &copy;</p>
    </footer>
    <script src="/build/js/bundle.min.js"></script>
  </body>
</html>
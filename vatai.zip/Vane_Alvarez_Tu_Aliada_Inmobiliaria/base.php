<?php 

require 'includes/funciones.php';
incluirTemplate('header.php');
?>

<main class="contenedor seccion">
    <h1>Titulo de página</h1>
</main>

<?php incluirTemplate('footer.php'); ?>